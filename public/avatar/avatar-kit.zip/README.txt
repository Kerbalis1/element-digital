ELEMENT DIGITAL — аватар с вращающимися шариками

ELEMENT-DIGITAL-orbit.mp4: 800×800, H.264, 30 кадров/с,
8 секунд, без звука. Два шарика движутся по общей орбите
с изменением масштаба и перекрытием неподвижной буквой E.
ELEMENT-DIGITAL-orbit-cover.jpg — статичная обложка.

В профиле бота этот файл автоматически не установлен.

Установка:
Распакуйте архив. Оставьте MP4 и install_avatar.py в одной папке.
На компьютере с Python 3 выполните: python install_avatar.py
В Windows можно использовать: py install_avatar.py
Введите токен BotFather в скрытом поле терминала.
Токен не сохраняется в файлы. Скрипт проверяет имя бота
@ElementDigitalStudioBot и устанавливает только его аватар.

Официальный метод:
https://core.telegram.org/bots/api#setmyprofilephoto
