"""Install this animated profile image using the official Telegram Bot API.
The token is requested privately at runtime and is never stored in a file.
"""
import getpass
import json
import pathlib
import sys
import urllib.error
import urllib.request
import uuid

EXPECTED_BOT = 'elementdigitalstudiobot'
video = pathlib.Path(__file__).with_name('ELEMENT-DIGITAL-orbit.mp4')
if not video.is_file():
    sys.exit('Положите MP4 рядом с этим скриптом.')
token = getpass.getpass('Токен бота из BotFather (ввод скрыт): ').strip()
base = 'https://api.telegram.org/bot' + token + '/'
try:
    with urllib.request.urlopen(urllib.request.Request(base+'getMe', method='POST'), timeout=20) as response:
        identity = json.load(response)
    if not identity.get('ok') or identity.get('result', {}).get('username', '').lower() != EXPECTED_BOT:
        sys.exit('Токен принадлежит другому боту или не принят. Аватар не изменён.')
    boundary = 'ElementAvatar' + uuid.uuid4().hex
    profile = json.dumps({'type':'animated','animation':'attach://avatar','main_frame_timestamp':0})
    body = (
        ('--'+boundary+'\r\nContent-Disposition: form-data; name="photo"\r\n\r\n'+profile+'\r\n').encode()
        + ('--'+boundary+'\r\nContent-Disposition: form-data; name="avatar"; filename="avatar.mp4"\r\nContent-Type: video/mp4\r\n\r\n').encode()
        + video.read_bytes()
        + ('\r\n--'+boundary+'--\r\n').encode()
    )
    request = urllib.request.Request(base+'setMyProfilePhoto', data=body, headers={'Content-Type':'multipart/form-data; boundary='+boundary}, method='POST')
    with urllib.request.urlopen(request, timeout=60) as response:
        result = json.load(response)
    if result.get('ok') is True and result.get('result') is True:
        print('Готово: живой аватар установлен у @ElementDigitalStudioBot.')
    else:
        sys.exit('Telegram не подтвердил установку аватара.')
except urllib.error.HTTPError as error:
    sys.exit('Telegram не принял запрос (HTTP '+str(error.code)+'). Проверьте токен и повторите.')
except Exception:
    sys.exit('Не удалось связаться с Telegram. Токен не сохранён. Проверьте подключение и повторите.')
